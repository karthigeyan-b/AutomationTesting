package org.dailybuzz.utils;

import java.util.Arrays;
import java.util.List;

public class Constans {

	public static String URL = "https://karthigeyan-b.github.io/dailybuzzburger";
	public static List<String> titles = Arrays.asList("About Daily Buzz Burger", "Our Menu", "Make a Reservation",
			"What Our Customers Say", "Gallery", "Contact Us");

}
